const avatarCharacters = [
    {
        name: "Aang",
        age: 112,
        element: "Air"
    },
    {
        name: "Katara",
        age: 16,
        element: "Water"
    },
    {
        name: "Sokka",
        age: 17,
        element: "Non-bender"
    },
    {
        name: "Zuko",
        age: 17,
        element: "Fire"
    },
    {
        name: "Toph",
        age: 12,
        element: "Earth"
    },
    {
        name: "Iroh",
        age: 60,
        element: "Fire"
    },
    {
        name: "Azula",
        age: 14,
        element: "Fire"
    },
    {
        name: "Mai",
        age: 15,
        element: "Non-bender"
    },
    {
        name: "Ty Lee",
        age: 15,
        element: "Non-bender"
    },
    {
        name: "Suki",
        age: 16,
        element: "Non-bender"
    },
    {
        name: "King Bumi",
        age: 112,
        element: "Earth"
    },
    {
        name: "Ozai",
        age: 43,
        element: "Fire"
    },
    {
        name: "Gran Gran",
        age: 85,
        element: "Water"
    },
    {
        name: "Pakku",
        age: 70,
        element: "Water"
    },
    {
        name: "Jeong Jeong",
        age: 70,
        element: "Fire"
    },
    {
        name: "Hakoda",
        age: 40,
        element: "Non-bender"
    },
    {
        name: "Bato",
        age: 45,
        element: "Non-bender"
    },
    {
        name: "Jet",
        age: 16,
        element: "Non-bender"
    },
    {
        name: "Long Feng",
        age: 55,
        element: "Non-bender"
    },
    {
        name: "Haru",
        age: 16,
        element: "Earth"
    }
];

// ==================== TASK 1 ====================

const taskA = document.querySelector('#task-a')
const taskB = document.querySelector('#task-b')
const taskC = document.querySelector('#task-c')

// A) What kind of 'element' is what Zuko bends?

const zukosElem = avatarCharacters.find( e => {
    if (e.name === 'Zuko') {
        return console.log(e.element);
    }
});

// B) Are all characters adults (older than 18 years)? Display, 'Yes.' or 'No.' into the given field.
const Adult = avatarCharacters.every( e => {
    if (e.age > 18) {
        return console.log("Yes");
    }else{
        return console.log("No")
    }
});

// C) List the names of waterbenders!
const aquaBenders = avatarCharacters.find( e => {
    if (e.element === "Water") {
         return console.log(e.name);
    }
});
document.getElementById('task-a').innerText = zukosElem;
document.getElementById('task-b').innerText = Adult;
document.getElementById('task-c').innerText = aquaBenders;
//i dont know why it isnt printing on the html website 
// ==================== TASK 2 ====================

let selected = []
const table = document.querySelector('table')

 /* A) YOU SHOULD INSERT YOUR SOLUTION HERE */
 //here we did delegation to choose td out of the tree and color the backgrounds when clicking 
 table.addEventListener('click', (e) => {
    if (e.target.tagName === 'td') {
        if (selected.length === 4) {
            selected = [];
            const tds = document.querySelectorAll('td');
            tds.forEach(td => td.style.backgroundColor = '');
        }
        e.target.style.backgroundColor = 'lightgreen';
        selected.push(e.target.innerText);
    }
});

document.querySelector('button').addEventListener('click', (e) => {
    if(selected.length == 4){
        // generate an unordered list (ul) out of the selected array! 
        // First create a `ul` and then append list items `li`-s inside of it.
        // After that, append the created ul to the div with the id `#answers`
        /* B) YOU SHOULD INSERT YOUR SOLUTION HERE */
        const ul = document.createElement('ul');
        selected.forEach(item => {
            const li = document.createElement('li');
            li.textContent = item;
            ul.appendChild(li);
        });
        const newanswers = document.getElementById('#answers');
        newanswers.appendChild(ul);

        const p = document.createElement("p")
        if(checkElementInQuartets()){
            p.classList.add('good')
            p.innerHTML = 'YEEES! Nice job! 😊'
        } else {
            p.classList.add('bad')
            p.innerHTML = 'Try again 😭'
        }
        ul.append(p)
    }
})
function checkElementInQuartets() {
    const goodies = [
        ["Dog", "Cat", "Hen", "Rabbit"],
        ["Cheese", "Meat", "Rice", "Eggs"],
        ["Watermelon", "Cherry", "Lemon", "Grapes"],
        ["Socks", "Gloves", "Scarf", "Boots"]
    ];
    let isGood = false;
    for (let i = 0; i < goodies.length; i++) {
        const quartet = goodies[i];
        let foundAll = true;
        for (let j = 0; j < selected.length; j++) {
            if (!quartet.includes(selected[j])) {
                foundAll = false;
                break;
            }
        }
        if (foundAll) {
            isGood = true;
            break;
        }
    }
    return isGood;
}

